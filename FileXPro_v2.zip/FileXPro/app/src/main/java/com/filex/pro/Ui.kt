package com.filex.pro

import android.graphics.Bitmap
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.Locale

object C {
    val Bg = Color(0xFF050A1E)
    val BgTop = Color(0xFF0B1550)
    val Card = Color(0xFF0D1636)
    val CardHi = Color(0xFF16214F)
    val Blue = Color(0xFF2979FF)
    val Cyan = Color(0xFF22D3EE)
    val Violet = Color(0xFF7C4DFF)
    val Ok = Color(0xFF00E676)
    val Warn = Color(0xFFFFB300)
    val Err = Color(0xFFFF5252)
    val Lo = Color(0xFF9AA6C8)
    val brand = Brush.horizontalGradient(listOf(Color(0xFF2979FF), Color(0xFF7C4DFF)))
    val sendBrush = Brush.linearGradient(listOf(Color(0xFF2979FF), Color(0xFF1E88E5), Color(0xFF22D3EE)))
    val recvBrush = Brush.linearGradient(listOf(Color(0xFF7C4DFF), Color(0xFF9C27B0), Color(0xFFE040FB)))
}

@Composable
fun FXTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Blue, secondary = C.Violet, background = C.Bg, surface = C.Card,
            onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
        ),
        content = content
    )
}

// ---------- تنسيقات ----------
fun fmtSize(b: Long): String = when {
    b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    b >= 1L shl 10 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}

fun fmtSpeed(bps: Double): String = String.format(Locale.US, "%.1f MB/s", bps / 1048576.0)

fun fmtTime(s: Long): String = when {
    s < 0 -> "--:--"
    s >= 3600 -> String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    else -> String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}

fun fmtDuration(ms: Long): String = fmtTime(ms / 1000)

fun qrBitmap(text: String, size: Int = 720): Bitmap {
    val hints = mapOf(EncodeHintType.MARGIN to 1, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M)
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
    val px = IntArray(size * size)
    val dark = 0xFF0A1030.toInt()
    val white = 0xFFFFFFFF.toInt()
    for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m[x, y]) dark else white
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    bmp.setPixels(px, 0, size, 0, 0, size, size)
    return bmp
}

// ---------- مكوّنات ----------
fun Modifier.card(radius: Dp = 20.dp, bg: Color = C.Card): Modifier =
    this.clip(RoundedCornerShape(radius)).background(bg)
        .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(radius))

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().drawBehind {
            drawRect(Brush.verticalGradient(listOf(C.BgTop, C.Bg), endY = size.height * 0.75f))
            drawCircle(
                Brush.radialGradient(
                    listOf(C.Violet.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(size.width * 0.95f, 0f), radius = size.width * 0.9f
                ),
                radius = size.width * 0.9f, center = Offset(size.width * 0.95f, 0f)
            )
        },
        content = content
    )
}

@Composable
fun CrownIcon(s: Dp = 28.dp) {
    Canvas(Modifier.size(s)) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(w * 0.08f, h * 0.88f)
            lineTo(w * 0.02f, h * 0.30f)
            lineTo(w * 0.28f, h * 0.55f)
            lineTo(w * 0.50f, h * 0.12f)
            lineTo(w * 0.72f, h * 0.55f)
            lineTo(w * 0.98f, h * 0.30f)
            lineTo(w * 0.92f, h * 0.88f)
            close()
        }
        drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFFE082), Color(0xFFFFA000))))
        val gold = Color(0xFFFFE082)
        drawCircle(gold, w * 0.07f, Offset(w * 0.02f, h * 0.28f))
        drawCircle(gold, w * 0.07f, Offset(w * 0.50f, h * 0.10f))
        drawCircle(gold, w * 0.07f, Offset(w * 0.98f, h * 0.28f))
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    brush: Brush = C.brand,
    enabled: Boolean = true
) {
    Row(
        modifier.alpha(if (enabled) 1f else 0.4f).height(54.dp).clip(RoundedCornerShape(18.dp))
            .background(brush).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = Color.White) {
    Box(
        modifier.height(50.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.08f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = color, fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
fun IconBubble(icon: ImageVector, tint: Color = Color.White, bg: Color = Color.White.copy(alpha = 0.14f), size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White) }
        } else {
            Spacer(Modifier.width(12.dp))
        }
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
        trailing()
    }
}

@Composable
fun ProgressRing(progress: Float, modifier: Modifier = Modifier, stroke: Dp = 14.dp, content: @Composable BoxScope.() -> Unit) {
    val p by animateFloatAsState(progress, tween(350), label = "ring")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val arcSize = Size(size.width - sw, size.height - sw)
            val tl = Offset(sw / 2, sw / 2)
            drawArc(Color.White.copy(alpha = 0.08f), 0f, 360f, false, tl, arcSize, style = Stroke(sw))
            if (p > 0.001f) {
                rotate(-90f) {
                    drawArc(
                        Brush.sweepGradient(listOf(C.Blue, C.Cyan, C.Violet, C.Blue)),
                        0f, 360f * p, false, tl, arcSize, style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
            }
        }
        content()
    }
}

@Composable
fun PulseRings(modifier: Modifier = Modifier, color: Color = C.Blue) {
    val t = rememberInfiniteTransition(label = "pulse")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "ph")
    Canvas(modifier) {
        val maxR = size.minDimension / 2
        for (i in 0 until 3) {
            val f = (phase + i / 3f) % 1f
            drawCircle(color.copy(alpha = ((1f - f) * 0.35f).coerceIn(0f, 1f)), radius = maxR * (0.55f + 0.45f * f), style = Stroke(3.dp.toPx()))
        }
    }
}

@Composable
fun Signature(modifier: Modifier = Modifier) {
    Text(
        "By : Adem Hadyaoui", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp,
        modifier = modifier.fillMaxWidth().padding(12.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
}
