package com.filex.pro

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.security.MessageDigest
import javax.crypto.Cipher

class EngineError(val info: ErrInfo) : Exception()
class CancelledEx : Exception()
class HttpCode(val code: Int) : IOException("HTTP $code")

/** قياس السرعة (متوسط متحرك) + تحديد وتيرة تحديث الواجهة */
class Meter {
    private var done = 0L
    private var lastT = 0L
    private var lastDone = 0L

    @Volatile
    var speed = 0.0
        private set

    @Synchronized
    fun add(n: Long): Boolean {
        done += n
        val now = SystemClock.elapsedRealtime()
        if (lastT == 0L) {
            lastT = now
            lastDone = done
            return true
        }
        val dt = now - lastT
        if (dt < 250) return false
        val inst = (done - lastDone) * 1000.0 / dt
        speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
        lastT = now
        lastDone = done
        return true
    }

    @Synchronized
    fun total(): Long = done
}

class TapStream(ins: InputStream, private val tap: (ByteArray, Int, Int) -> Unit) : FilterInputStream(ins) {
    override fun read(): Int {
        val r = super.read()
        if (r >= 0) tap(byteArrayOf(r.toByte()), 0, 1)
        return r
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0) tap(b, off, n)
        return n
    }
}

class SenderServer(
    private val ctx: Context,
    private val files: List<PickedFile>,
    private val token: String,
    private val key: ByteArray,
    private val nonce: ByteArray,
    private val deviceName: String,
    port: Int,
    private val listener: Listener
) : NanoHTTPD(port) {

    interface Listener {
        fun onPeer(ip: String, name: String)
        fun onFileStart(index: Int)
        fun onBytes(n: Long)
        fun onFin(ok: Int, bad: Int, cancelled: Boolean)
    }

    private val lock = Any()
    private val digests = arrayOfNulls<MessageDigest>(files.size)
    private val sums = arrayOfNulls<String>(files.size)
    private var peerIp: String? = null

    private fun text(status: Response.Status, msg: String): Response =
        newFixedLengthResponse(status, "text/plain", msg)

    private fun bin(data: ByteArray): Response =
        newFixedLengthResponse(
            Response.Status.OK, "application/octet-stream",
            ByteArrayInputStream(data), data.size.toLong()
        )

    override fun serve(session: IHTTPSession): Response {
        if (session.parms["t"] != token) return text(Response.Status.FORBIDDEN, "forbidden")
        val ip = session.remoteIpAddress ?: ""
        synchronized(lock) {
            val p = peerIp
            if (p == null) {
                peerIp = ip
            } else if (p != ip) {
                return text(Response.Status.FORBIDDEN, "busy")
            }
        }
        val path = session.uri
        return try {
            when {
                path == "/list" -> {
                    listener.onPeer(ip, session.parms["d"] ?: "")
                    val arr = JSONArray()
                    files.forEach { f ->
                        arr.put(JSONObject().put("name", f.name).put("size", f.size).put("mime", f.mime))
                    }
                    val json = JSONObject().put("v", 2).put("device", deviceName).put("files", arr).toString()
                    bin(Crypto.encryptBytes(json.toByteArray(Charsets.UTF_8), key, nonce, Crypto.LIST_IDX))
                }
                path.startsWith("/file/") -> {
                    val idx = path.removePrefix("/file/").toIntOrNull() ?: -1
                    if (idx !in files.indices) return text(Response.Status.NOT_FOUND, "not found")
                    val f = files[idx]
                    val md = MessageDigest.getInstance("SHA-256")
                    synchronized(lock) {
                        digests[idx] = md
                        sums[idx] = null
                    }
                    listener.onFileStart(idx)
                    val raw = ctx.contentResolver.openInputStream(f.uri) ?: throw IOException("open failed")
                    val tap = TapStream(raw) { b, off, n ->
                        synchronized(lock) { md.update(b, off, n) }
                        listener.onBytes(n.toLong())
                    }
                    val enc = CtrStream(tap, Crypto.cipher(Cipher.ENCRYPT_MODE, key, nonce, Crypto.fileIdx(idx)))
                    newFixedLengthResponse(Response.Status.OK, "application/octet-stream", enc, f.size)
                }
                path.startsWith("/sum/") -> {
                    val idx = path.removePrefix("/sum/").toIntOrNull() ?: -1
                    if (idx !in files.indices) return text(Response.Status.NOT_FOUND, "not found")
                    val hex: String? = synchronized(lock) {
                        sums[idx] ?: digests[idx]?.digest()?.let { Crypto.hex(it) }?.also { sums[idx] = it }
                    }
                    if (hex == null) {
                        text(Response.Status.NOT_FOUND, "no sum")
                    } else {
                        bin(Crypto.encryptBytes(hex.toByteArray(Charsets.UTF_8), key, nonce, Crypto.sumIdx(idx)))
                    }
                }
                path == "/fin" -> {
                    val ok = session.parms["ok"]?.toIntOrNull() ?: 0
                    val bad = session.parms["bad"]?.toIntOrNull() ?: 0
                    listener.onFin(ok, bad, session.parms["c"] == "1")
                    text(Response.Status.OK, "ok")
                }
                else -> text(Response.Status.NOT_FOUND, "not found")
            }
        } catch (e: Exception) {
            text(Response.Status.INTERNAL_ERROR, e.message ?: "error")
        }
    }
}

object Engine {
    const val PORT = 8765

    val sendState = MutableStateFlow(TransferState())
    val recvState = MutableStateFlow(TransferState())
    val qr = MutableStateFlow<String?>(null)

    @Volatile private var server: SenderServer? = null
    @Volatile private var sendGen = 0
    @Volatile private var recvGen = 0
    @Volatile private var fallbackFor = -1
    private val main = Handler(Looper.getMainLooper())

    // ---------- أدوات ----------
    fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun queryFile(ctx: Context, uri: Uri): PickedFile {
        var name = "file"
        var size = -1L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) {
        }
        if (name == "file") {
            uri.lastPathSegment?.let { name = it.substringAfterLast('/') }
        }
        if (size <= 0) {
            size = try {
                ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            } catch (e: Exception) {
                -1L
            }
        }
        if (size < 0) size = measure(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: guessMime(name)
        return PickedFile(uri, name, size, mime, SRC_DOC)
    }

    private fun measure(ctx: Context, uri: Uri): Long {
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                val buf = ByteArray(64 * 1024)
                var n = 0L
                while (true) {
                    val r = ins.read(buf)
                    if (r < 0) break
                    n += r
                }
                n
            } ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    private fun localIps(): List<String> {
        val out = mutableListOf<String>()
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                if (!ni.isUp || ni.isLoopback) return@forEach
                val n = ni.name ?: ""
                val lan = n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") ||
                    n.startsWith("p2p") || n.startsWith("eth")
                if (!lan) return@forEach
                ni.inetAddresses.toList().forEach { a ->
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        val h = a.hostAddress
                        if (h != null) out.add(h)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out.distinct()
    }

    // ---------- المرسل ----------
    private fun teardownServer() {
        try {
            server?.stop()
        } catch (e: Exception) {
        }
        server = null
    }

    fun stopSending() {
        sendGen++
        teardownServer()
        qr.value = null
        sendState.value = TransferState()
    }

    private fun sFail(my: Int, info: ErrInfo) {
        if (my == sendGen) {
            sendState.update { it.copy(phase = Phase.Failed, error = info, finishedAt = System.currentTimeMillis()) }
        }
    }

    private fun finishSend(app: Context, my: Int, ok: Int, bad: Int, cancelled: Boolean) {
        if (my != sendGen) return
        val cur = sendState.value
        if (cur.phase != Phase.Transferring) return
        val now = System.currentTimeMillis()
        if (cancelled) {
            sendState.value = cur.copy(phase = Phase.Failed, error = ErrInfo(R.string.err_peer_cancelled), finishedAt = now)
        } else {
            sendState.value = cur.copy(
                phase = Phase.Done, doneBytes = cur.totalBytes, currentIndex = cur.fileCount,
                verified = ok, mismatched = bad, finishedAt = now
            )
            addHistory(app, "sent", cur.fileCount, cur.totalBytes, bad == 0, cur.peerName, (now - cur.startedAt) / 1000)
        }
        main.postDelayed({ if (my == sendGen) teardownServer() }, 1500)
    }

    private fun scheduleSendFallback(app: Context, my: Int) {
        if (fallbackFor == my) return
        fallbackFor = my
        main.postDelayed({
            if (my == sendGen && sendState.value.phase == Phase.Transferring) finishSend(app, my, 0, 0, false)
        }, 10000)
    }

    fun startSending(ctx: Context, files: List<PickedFile>) {
        val app = ctx.applicationContext
        teardownServer()
        val my = ++sendGen
        qr.value = null
        val total = files.sumOf { it.size }
        sendState.value = TransferState(
            phase = Phase.Preparing,
            names = files.map { it.name },
            sizes = files.map { it.size },
            totalBytes = total
        )
        TransferService.start(app)
        Thread {
            try {
                val ips = localIps()
                if (ips.isEmpty()) throw EngineError(ErrInfo(R.string.err_no_network))
                val key = Crypto.newKey()
                val nonce = Crypto.newNonce()
                val token = Crypto.hex(Crypto.newKey())
                val meter = Meter()
                val listener = object : SenderServer.Listener {
                    override fun onPeer(ip: String, name: String) {
                        if (my != sendGen) return
                        sendState.update {
                            if (it.phase == Phase.Waiting || it.phase == Phase.Preparing) {
                                it.copy(
                                    phase = Phase.Transferring,
                                    peerName = name.ifBlank { ip },
                                    startedAt = System.currentTimeMillis()
                                )
                            } else it
                        }
                    }

                    override fun onFileStart(index: Int) {
                        if (my == sendGen) sendState.update { it.copy(currentIndex = index) }
                    }

                    override fun onBytes(n: Long) {
                        if (my != sendGen) return
                        val emit = meter.add(n)
                        val d = meter.total().coerceAtMost(total)
                        if (emit || (total > 0 && d >= total)) {
                            sendState.update { it.copy(doneBytes = d, speedBps = meter.speed) }
                        }
                        if (total > 0 && d >= total) scheduleSendFallback(app, my)
                    }

                    override fun onFin(ok: Int, bad: Int, cancelled: Boolean) {
                        finishSend(app, my, ok, bad, cancelled)
                    }
                }
                val devName = Prefs.deviceName(app)
                var s = SenderServer(app, files, token, key, nonce, devName, PORT, listener)
                try {
                    s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                } catch (e: IOException) {
                    s = SenderServer(app, files, token, key, nonce, devName, 0, listener)
                    s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                }
                if (my != sendGen) {
                    s.stop()
                    return@Thread
                }
                server = s
                val sb = StringBuilder("filex://connect?")
                sb.append("h=").append(ips.joinToString(","))
                sb.append("&p=").append(s.listeningPort)
                sb.append("&t=").append(token)
                sb.append("&k=").append(Crypto.hex(key))
                sb.append("&c=").append(Crypto.hex(nonce))
                sb.append("&n=").append(Uri.encode(devName))
                sb.append("&v=2")
                qr.value = sb.toString()
                sendState.update {
                    if (my == sendGen && it.phase == Phase.Preparing) it.copy(phase = Phase.Waiting) else it
                }
            } catch (e: EngineError) {
                sFail(my, e.info)
            } catch (e: Exception) {
                sFail(my, ErrInfo(R.string.err_generic, e.message))
            }
        }.start()
    }

    // ---------- المستقبل ----------
    fun cancelReceive() {
        recvGen++
        recvState.value = TransferState()
    }

    fun clearReceiveIfIdle() {
        if (!recvState.value.busy) recvState.value = TransferState()
    }

    fun cancelAll() {
        stopSending()
        cancelReceive()
    }

    private fun rUpdate(my: Int, f: (TransferState) -> TransferState) {
        if (my == recvGen) recvState.update(f)
    }

    private fun checkAlive(my: Int) {
        if (my != recvGen) throw CancelledEx()
    }

    private fun rFail(my: Int, info: ErrInfo) {
        rUpdate(my) { it.copy(phase = Phase.Failed, error = info, finishedAt = System.currentTimeMillis()) }
    }

    @Suppress("DEPRECATION")
    private fun candidateNetworks(ctx: Context): List<Network?> {
        val out = mutableListOf<Network?>()
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) out.add(n)
            }
        } catch (e: Exception) {
        }
        out.add(null)
        return out
    }

    private fun openConn(net: Network?, url: String, timeout: Int): HttpURLConnection {
        val u = URL(url)
        val c = (if (net != null) net.openConnection(u) else u.openConnection()) as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = 30000
        c.useCaches = false
        return c
    }

    private fun httpBytes(net: Network?, url: String, timeout: Int): ByteArray {
        val c = openConn(net, url, timeout)
        try {
            if (c.responseCode != 200) throw HttpCode(c.responseCode)
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private fun parseHex(s: String?): ByteArray? =
        try {
            if (s == null) null else Crypto.unhex(s)
        } catch (e: Exception) {
            null
        }

    private fun checkStorage(total: Long) {
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            if (st.availableBytes < total + 64L * 1024 * 1024) throw EngineError(ErrInfo(R.string.err_no_space))
        } catch (e: EngineError) {
            throw e
        } catch (e: Exception) {
        }
    }

    private fun safeName(n: String): String {
        val s = n.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trimStart('.')
        return if (s.isEmpty()) "file" else s.take(120)
    }

    private class Sink(val out: OutputStream, val commit: () -> Unit, val discard: () -> Unit)

    /** أندرويد 10+: MediaStore (صور/فيديو/صوت/تنزيلات) ، أندرويد 9 وأقل: مجلدات FileX مباشرة */
    private fun openSink(ctx: Context, name: String, mime: String): Sink {
        val kind = when {
            mime.startsWith("image/") -> 1
            mime.startsWith("video/") -> 2
            mime.startsWith("audio/") -> 3
            else -> 0
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = ctx.contentResolver
            val target: Pair<Uri, String> = when (kind) {
                1 -> Pair(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Environment.DIRECTORY_PICTURES)
                2 -> Pair(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Environment.DIRECTORY_MOVIES)
                3 -> Pair(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Environment.DIRECTORY_MUSIC)
                else -> Pair(MediaStore.Downloads.EXTERNAL_CONTENT_URI, Environment.DIRECTORY_DOWNLOADS)
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, target.second + "/FileX")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = resolver.insert(target.first, values) ?: throw IOException("insert failed")
            val out = resolver.openOutputStream(dst) ?: throw IOException("open failed")
            return Sink(
                out,
                {
                    val v = ContentValues()
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(dst, v, null, null)
                },
                { resolver.delete(dst, null, null) }
            )
        }
        val dirType = when (kind) {
            1 -> Environment.DIRECTORY_PICTURES
            2 -> Environment.DIRECTORY_MOVIES
            3 -> Environment.DIRECTORY_MUSIC
            else -> Environment.DIRECTORY_DOWNLOADS
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(dirType), "FileX")
        dir.mkdirs()
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var f = File(dir, name)
        var k = 1
        while (f.exists()) {
            f = File(dir, "$base ($k)$ext")
            k++
        }
        val target = f
        return Sink(
            FileOutputStream(target),
            { MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), null, null) },
            { target.delete() }
        )
    }

    fun receive(ctx: Context, payload: String) {
        val app = ctx.applicationContext
        val my = ++recvGen
        recvState.value = TransferState(phase = Phase.Preparing, startedAt = System.currentTimeMillis())
        TransferService.start(app)
        Thread { runReceive(app, payload, my) }.start()
    }

    private fun runReceive(ctx: Context, payload: String, my: Int) {
        var base: String? = null
        var token = ""
        var net: Network? = null
        try {
            val u = Uri.parse(payload)
            if (u.scheme != "filex" || u.getQueryParameter("v") != "2") throw EngineError(ErrInfo(R.string.err_bad_qr))
            val hosts = (u.getQueryParameter("h") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val port = u.getQueryParameter("p")?.toIntOrNull() ?: PORT
            token = u.getQueryParameter("t") ?: throw EngineError(ErrInfo(R.string.err_bad_qr))
            val key = parseHex(u.getQueryParameter("k")) ?: throw EngineError(ErrInfo(R.string.err_bad_qr))
            val nonce = parseHex(u.getQueryParameter("c")) ?: throw EngineError(ErrInfo(R.string.err_bad_qr))
            if (hosts.isEmpty() || key.size != 16 || nonce.size != 8) throw EngineError(ErrInfo(R.string.err_bad_qr))

            val me = Uri.encode(Prefs.deviceName(ctx))
            val nets = candidateNetworks(ctx)
            var listBytes: ByteArray? = null
            var lastCode = 0
            search@ for (h in hosts) {
                for (cand in nets) {
                    checkAlive(my)
                    try {
                        listBytes = httpBytes(cand, "http://$h:$port/list?t=$token&d=$me", 3500)
                        base = "http://$h:$port"
                        net = cand
                        break@search
                    } catch (e: HttpCode) {
                        lastCode = e.code
                    } catch (e: IOException) {
                    }
                }
            }
            val lb = listBytes
            val b = base
            if (lb == null || b == null) {
                throw EngineError(ErrInfo(if (lastCode == 403) R.string.err_busy else R.string.err_unreachable))
            }

            val json = try {
                JSONObject(String(Crypto.decryptBytes(lb, key, nonce, Crypto.LIST_IDX), Charsets.UTF_8))
            } catch (e: Exception) {
                throw EngineError(ErrInfo(R.string.err_bad_qr))
            }
            val arr = json.getJSONArray("files")
            val n = arr.length()
            val names = ArrayList<String>()
            val sizes = ArrayList<Long>()
            val mimes = ArrayList<String>()
            for (i in 0 until n) {
                val o = arr.getJSONObject(i)
                val nm = safeName(o.getString("name"))
                names.add(nm)
                sizes.add(o.getLong("size"))
                mimes.add(o.optString("mime", "").ifBlank { guessMime(nm) })
            }
            val total = sizes.sum()
            val peer = json.optString("device", "").ifBlank { u.getQueryParameter("n") ?: "" }
            checkStorage(total)
            rUpdate(my) {
                it.copy(
                    phase = Phase.Transferring, names = names, sizes = sizes,
                    totalBytes = total, peerName = peer
                )
            }

            val meter = Meter()
            var ok = 0
            var bad = 0
            var done = 0L
            val failed = HashSet<Int>()
            for (i in 0 until n) {
                checkAlive(my)
                rUpdate(my) { it.copy(currentIndex = i) }
                val conn = openConn(net, "$b/file/$i?t=$token", 10000)
                var sink: Sink? = null
                var committed = false
                try {
                    if (conn.responseCode != 200) throw HttpCode(conn.responseCode)
                    val md = MessageDigest.getInstance("SHA-256")
                    val dec = Crypto.cipher(Cipher.DECRYPT_MODE, key, nonce, Crypto.fileIdx(i))
                    val sk = openSink(ctx, names[i], mimes[i])
                    sink = sk
                    var got = 0L
                    conn.inputStream.use { input ->
                        sk.out.use { out ->
                            val buf = ByteArray(256 * 1024)
                            val dbuf = ByteArray(256 * 1024)
                            while (true) {
                                checkAlive(my)
                                val r = input.read(buf)
                                if (r < 0) break
                                val o = dec.update(buf, 0, r, dbuf, 0)
                                out.write(dbuf, 0, o)
                                md.update(dbuf, 0, o)
                                got += o
                                done += o
                                if (meter.add(o.toLong())) {
                                    val dNow = done
                                    rUpdate(my) { it.copy(doneBytes = dNow, speedBps = meter.speed) }
                                }
                            }
                        }
                    }
                    if (got != sizes[i]) throw IOException("size mismatch")
                    val remote = String(
                        Crypto.decryptBytes(
                            httpBytes(net, "$b/sum/$i?t=$token", 10000), key, nonce, Crypto.sumIdx(i)
                        ),
                        Charsets.UTF_8
                    )
                    if (remote.equals(Crypto.hex(md.digest()), ignoreCase = true)) {
                        sk.commit()
                        committed = true
                        ok++
                    } else {
                        bad++
                        failed.add(i)
                    }
                } finally {
                    if (!committed) sink?.let { s -> s.discard() }
                    conn.disconnect()
                }
            }

            val now = System.currentTimeMillis()
            if (my == recvGen) {
                val started = recvState.value.startedAt
                rUpdate(my) {
                    it.copy(
                        phase = Phase.Done, doneBytes = total, currentIndex = n, failed = failed.toSet(),
                        verified = ok, mismatched = bad, finishedAt = now
                    )
                }
                addHistory(ctx, "received", n, total, bad == 0, peer, (now - started) / 1000)
            }
            try {
                httpBytes(net, "$b/fin?t=$token&ok=$ok&bad=$bad&c=0", 4000)
            } catch (e: Exception) {
            }
        } catch (e: CancelledEx) {
            notifyFin(net, base, token)
        } catch (e: EngineError) {
            rFail(my, e.info)
            notifyFin(net, base, token)
        } catch (e: HttpCode) {
            rFail(my, ErrInfo(if (e.code == 403) R.string.err_busy else R.string.err_connection_lost))
            notifyFin(net, base, token)
        } catch (e: IOException) {
            rFail(my, ErrInfo(R.string.err_connection_lost))
            notifyFin(net, base, token)
        } catch (e: Exception) {
            rFail(my, ErrInfo(R.string.err_generic, e.message))
            notifyFin(net, base, token)
        }
    }

    private fun notifyFin(net: Network?, base: String?, token: String) {
        if (base == null) return
        try {
            httpBytes(net, "$base/fin?t=$token&ok=0&bad=0&c=1", 3000)
        } catch (e: Exception) {
        }
    }

    // ---------- السجل ----------
    fun addHistory(ctx: Context, dir: String, count: Int, bytes: Long, ok: Boolean, peer: String, durSec: Long) {
        val p = ctx.getSharedPreferences("filex", Context.MODE_PRIVATE)
        val old = try {
            JSONArray(p.getString("h", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val out = JSONArray()
        out.put(
            JSONObject().put("t", System.currentTimeMillis()).put("d", dir).put("c", count)
                .put("b", bytes).put("ok", ok).put("p", peer).put("s", durSec)
        )
        for (i in 0 until minOf(old.length(), 99)) out.put(old.get(i))
        p.edit().putString("h", out.toString()).apply()
    }

    fun history(ctx: Context): List<HistoryItem> {
        val p = ctx.getSharedPreferences("filex", Context.MODE_PRIVATE)
        val a = try {
            JSONArray(p.getString("h", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(
                o.getLong("t"), o.getString("d"), o.getInt("c"), o.getLong("b"), o.getBoolean("ok"),
                o.optString("p", ""), o.optLong("s", 0L)
            )
        }
    }

    fun clearHistory(ctx: Context) {
        ctx.getSharedPreferences("filex", Context.MODE_PRIVATE).edit().remove("h").apply()
    }
}
