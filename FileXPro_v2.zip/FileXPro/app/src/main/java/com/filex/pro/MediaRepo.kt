package com.filex.pro

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object MediaRepo {
    private const val APK_MIME = "application/vnd.android.package-archive"

    fun requiredPerms(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO
        )
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun granted(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun hasMedia(ctx: Context, video: Boolean): Boolean {
        val sdk = Build.VERSION.SDK_INT
        if (sdk >= 33) {
            val p = if (video) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_MEDIA_IMAGES
            return granted(ctx, p) ||
                (sdk >= 34 && granted(ctx, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED))
        }
        return granted(ctx, Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    fun queryMedia(ctx: Context, video: Boolean): List<MediaItem> {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = if (video) {
            arrayOf(
                MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE, MediaStore.Video.VideoColumns.DURATION
            )
        } else {
            arrayOf(
                MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE
            )
        }
        val out = ArrayList<MediaItem>()
        try {
            ctx.contentResolver.query(base, proj, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: "file_$id"
                    val size = c.getLong(2)
                    val mime = c.getString(3) ?: (if (video) "video/*" else "image/*")
                    val dur = if (video) c.getLong(4) else 0L
                    if (size <= 0) continue
                    out.add(MediaItem(id, ContentUris.withAppendedId(base, id), name, size, mime, video, dur))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun apkFiles(label: String, ai: ApplicationInfo): List<PickedFile> {
        val paths = ArrayList<String>()
        ai.sourceDir?.let { paths.add(it) }
        ai.splitSourceDirs?.forEach { paths.add(it) }
        val safe = label.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { ai.packageName }
        val files = ArrayList<PickedFile>()
        paths.forEachIndexed { idx, p ->
            val f = File(p)
            if (f.exists()) {
                val nm = when {
                    paths.size == 1 -> "$safe.apk"
                    idx == 0 -> "$safe (base).apk"
                    else -> "$safe (split$idx).apk"
                }
                files.add(PickedFile(Uri.fromFile(f), nm, f.length(), APK_MIME, SRC_APP))
            }
        }
        return files
    }

    @Suppress("DEPRECATION")
    fun queryApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppItem>()
        try {
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo?.applicationInfo ?: continue
                val pkg = ai.packageName
                if (!seen.add(pkg)) continue
                val label = ai.loadLabel(pm).toString()
                val files = apkFiles(label, ai)
                if (files.isEmpty()) continue
                out.add(AppItem(pkg, label, files.sumOf { it.size }, files))
            }
        } catch (e: Exception) {
        }
        out.sortBy { it.label.lowercase() }
        return out
    }

    /** ملفات APK متاع التطبيق نفسو (لميزة "شارك التطبيق") */
    fun selfApk(ctx: Context): List<PickedFile> = apkFiles("FileX Pro", ctx.applicationInfo)
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun peek(key: String): Bitmap? = cache.get(key)

    @Suppress("DEPRECATION")
    suspend fun media(ctx: Context, m: MediaItem): Bitmap? = withContext(Dispatchers.IO) {
        val key = m.uri.toString()
        val hit = cache.get(key)
        if (hit != null) return@withContext hit
        val bmp: Bitmap? = try {
            val cr = ctx.contentResolver
            if (Build.VERSION.SDK_INT >= 29) {
                cr.loadThumbnail(m.uri, Size(240, 240), null)
            } else if (m.video) {
                MediaStore.Video.Thumbnails.getThumbnail(cr, m.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
            } else {
                MediaStore.Images.Thumbnails.getThumbnail(cr, m.id, MediaStore.Images.Thumbnails.MINI_KIND, null)
            }
        } catch (e: Exception) {
            null
        }
        if (bmp != null) cache.put(key, bmp)
        bmp
    }

    suspend fun appIcon(ctx: Context, pkg: String): Bitmap? = withContext(Dispatchers.IO) {
        val key = "app:$pkg"
        val hit = cache.get(key)
        if (hit != null) return@withContext hit
        val bmp: Bitmap? = try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
        } catch (e: Exception) {
            null
        }
        if (bmp != null) cache.put(key, bmp)
        bmp
    }
}
