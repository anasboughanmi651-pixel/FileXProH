package com.filex.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** خدمة أمامية: النقل يكمل حتى كي الشاشة تتقفل أو التطبيق يتحط في الخلفية */
class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var lastNotify = 0L
    private var lastIsSend = true
    private var lastPhase = Phase.Idle
    private var lastStartId = 0

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Loc.wrap(newBase))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        if (intent?.action == ACTION_STOP) Engine.cancelAll()
        val s = Engine.sendState.value
        val r = Engine.recvState.value
        val isSend = s.busy || !r.busy
        try {
            startFg(progressNotif(if (isSend) s else r, isSend))
        } catch (e: Exception) {
        }
        acquireLocks()
        job?.cancel()
        job = scope.launch {
            combine(Engine.sendState, Engine.recvState) { a, b -> Pair(a, b) }.collect { pair ->
                val a = pair.first
                val b = pair.second
                if (!a.busy && !b.busy) {
                    finish(a, b)
                    return@collect
                }
                val send = a.busy
                val st = if (send) a else b
                lastIsSend = send
                val now = SystemClock.elapsedRealtime()
                if (now - lastNotify > 800 || st.phase != lastPhase) {
                    lastNotify = now
                    lastPhase = st.phase
                    try {
                        nm().notify(NOTIF_ID, progressNotif(st, send))
                    } catch (e: Exception) {
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun finish(a: TransferState, b: TransferState) {
        val st = if (lastIsSend) a else b
        try {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
        }
        if (!appVisible && (st.phase == Phase.Done || st.phase == Phase.Failed)) {
            try {
                nm().notify(RESULT_ID, resultNotif(st))
            } catch (e: Exception) {
            }
        }
        stopSelf(lastStartId)
    }

    override fun onDestroy() {
        scope.cancel()
        try {
            wake?.let { if (it.isHeld) it.release() }
            wifi?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        wake = null
        wifi = null
        super.onDestroy()
    }

    private fun startFg(n: Notification) {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            if (wake == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FileX:transfer")
                w.acquire(4 * 60 * 60 * 1000L)
                wake = w
            }
            if (wifi == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                val l = wm.createWifiLock(mode, "FileX:wifi")
                l.acquire()
                wifi = l
            }
        } catch (e: Exception) {
        }
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val m = nm()
            m.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, getString(R.string.notif_channel_progress), NotificationManager.IMPORTANCE_LOW)
            )
            m.createNotificationChannel(
                NotificationChannel(CH_RESULT, getString(R.string.notif_channel_result), NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    private fun openIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun stopIntent(): PendingIntent {
        val i = Intent(this, TransferService::class.java).setAction(ACTION_STOP)
        return PendingIntent.getService(this, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun progressNotif(st: TransferState, send: Boolean): Notification {
        val title = getString(if (send) R.string.notif_sending else R.string.notif_receiving)
        val pct = (st.percent * 100).toInt()
        val text = when (st.phase) {
            Phase.Transferring -> "$pct% · ${fmtSize(st.doneBytes)} / ${fmtSize(st.totalBytes)} · ${fmtSpeed(st.speedBps)}"
            Phase.Waiting -> getString(R.string.notif_waiting)
            else -> getString(R.string.notif_preparing)
        }
        val b = NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_transfer)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setContentIntent(openIntent())
            .addAction(0, getString(R.string.notif_stop), stopIntent())
            .setColor(0xFF2979FF.toInt())
        if (st.phase == Phase.Transferring) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun resultNotif(st: TransferState): Notification {
        val ok = st.phase == Phase.Done
        val text = if (ok) {
            getString(R.string.notif_done_text, st.fileCount, fmtSize(st.totalBytes))
        } else {
            val e = st.error
            if (e != null) getString(e.res, e.arg ?: "") else ""
        }
        return NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_stat_transfer)
            .setContentTitle(getString(if (ok) R.string.notif_done else R.string.notif_failed))
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openIntent())
            .setColor(0xFF2979FF.toInt())
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.filex.pro.STOP"
        private const val NOTIF_ID = 4101
        private const val RESULT_ID = 4102
        private const val CH_PROGRESS = "transfer_progress"
        private const val CH_RESULT = "transfer_result"

        @Volatile
        var appVisible = false

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, TransferService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
