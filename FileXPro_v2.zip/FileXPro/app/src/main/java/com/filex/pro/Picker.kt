package com.filex.pro

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun iconForName(name: String): ImageVector {
    val ext = name.substringAfterLast('.', "").lowercase()
    return when (ext) {
        "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> Icons.Rounded.Image
        "mp4", "mkv", "avi", "mov", "3gp", "webm" -> Icons.Rounded.Videocam
        "mp3", "m4a", "wav", "ogg", "aac", "flac", "opus" -> Icons.Rounded.MusicNote
        "apk" -> Icons.Rounded.Android
        else -> Icons.Rounded.Description
    }
}

@Composable
fun CheckDot(selected: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape)
            .background(if (selected) C.Blue else Color.Black.copy(alpha = 0.35f))
            .border(1.5.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun MediaCell(item: MediaItem, selected: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(Thumbs.peek(item.uri.toString()), item.uri) {
        if (value == null) value = Thumbs.media(ctx, item)
    }
    Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(C.Card).clickable(onClick = onClick)) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(
                if (item.video) Icons.Rounded.Videocam else Icons.Rounded.Image, null,
                tint = C.Lo.copy(alpha = 0.4f), modifier = Modifier.align(Alignment.Center).size(28.dp)
            )
        }
        if (selected) Box(Modifier.fillMaxSize().background(C.Blue.copy(alpha = 0.35f)))
        if (item.video) {
            Text(
                fmtDuration(item.durationMs), color = Color.White, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(5.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
        CheckDot(selected, Modifier.align(Alignment.TopEnd).padding(6.dp))
    }
}

@Composable
fun PermissionCard(onAllow: () -> Unit, onSystemPicker: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconBubble(Icons.Rounded.Lock, tint = C.Cyan, bg = C.Cyan.copy(alpha = 0.14f), size = 76.dp)
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.perm_title), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.perm_body), color = C.Lo, textAlign = TextAlign.Center, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        GradientButton(stringResource(R.string.perm_allow), onAllow, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        SoftButton(stringResource(R.string.perm_system_picker), onSystemPicker, Modifier.fillMaxWidth())
    }
}

@Composable
fun MediaGrid(video: Boolean, picked: SnapshotStateList<PickedFile>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(MediaRepo.hasMedia(ctx, video)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = MediaRepo.hasMedia(ctx, video)
    }
    val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        scope.launch {
            val files = withContext(Dispatchers.IO) { uris.map { Engine.queryFile(ctx, it) } }
            val have = picked.map { it.uri }.toHashSet()
            files.forEach { if (it.uri !in have) picked.add(it.copy(source = SRC_MEDIA)) }
        }
    }
    if (!granted) {
        PermissionCard(
            onAllow = { permLauncher.launch(MediaRepo.requiredPerms()) },
            onSystemPicker = {
                systemPicker.launch(
                    PickVisualMediaRequest(
                        if (video) ActivityResultContracts.PickVisualMedia.VideoOnly
                        else ActivityResultContracts.PickVisualMedia.ImageOnly
                    )
                )
            }
        )
        return
    }
    val loaded by produceState<List<MediaItem>?>(null, video, granted) {
        value = withContext(Dispatchers.IO) { MediaRepo.queryMedia(ctx, video) }
    }
    val list = loaded
    if (list == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            androidx.compose.material3.CircularProgressIndicator(color = C.Blue)
        }
        return
    }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.no_media), color = C.Lo)
        }
        return
    }
    val selectedUris = picked.map { it.uri }.toHashSet()
    val allSelected = list.all { it.uri in selectedUris }
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.items_count, list.size), color = C.Lo, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    if (allSelected) {
                        val all = list.map { it.uri }.toHashSet()
                        picked.removeAll { it.uri in all }
                    } else {
                        val have = picked.map { it.uri }.toHashSet()
                        picked.addAll(list.filter { it.uri !in have }.map { PickedFile(it.uri, it.name, it.size, it.mime, SRC_MEDIA) })
                    }
                }) { Text(stringResource(if (allSelected) R.string.deselect_all else R.string.select_all), color = C.Blue) }
            }
        }
        items(list, key = { it.id }) { m ->
            MediaCell(m, m.uri in selectedUris) {
                val i = picked.indexOfFirst { it.uri == m.uri }
                if (i >= 0) picked.removeAt(i) else picked.add(PickedFile(m.uri, m.name, m.size, m.mime, SRC_MEDIA))
            }
        }
    }
}

@Composable
fun SelectedRow(f: PickedFile, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).card(14.dp).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(iconForName(f.name), null, tint = C.Cyan, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = Color.White, maxLines = 1, fontSize = 14.sp)
            Text(fmtSize(f.size), color = C.Lo, fontSize = 12.sp)
        }
        Icon(Icons.Rounded.Close, null, tint = C.Lo, modifier = Modifier.size(28.dp).clickable(onClick = onRemove).padding(4.dp))
    }
}

@Composable
fun FilesTab(picked: SnapshotStateList<PickedFile>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        scope.launch {
            val files = withContext(Dispatchers.IO) { uris.map { Engine.queryFile(ctx, it) } }
            val have = picked.map { it.uri }.toHashSet()
            files.forEach { if (it.uri !in have) picked.add(it) }
        }
    }
    val docs = picked.filter { it.source == SRC_DOC }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Column(
            Modifier.fillMaxWidth().card(22.dp).clickable { launcher.launch(arrayOf("*/*")) }.padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            IconBubble(Icons.Rounded.Folder, tint = C.Violet, bg = C.Violet.copy(alpha = 0.16f), size = 64.dp)
            Spacer(Modifier.height(10.dp))
            Text(stringResource(R.string.browse_files), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(stringResource(R.string.browse_files_sub), color = C.Lo, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(docs, key = { it.uri.toString() }) { f ->
                SelectedRow(f) { picked.remove(f) }
            }
        }
    }
}

@Composable
fun AppRow(app: AppItem, selected: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val icon by produceState<Bitmap?>(Thumbs.peek("app:" + app.pkg), app.pkg) {
        if (value == null) value = Thumbs.appIcon(ctx, app.pkg)
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).card(14.dp, if (selected) C.CardHi else C.Card)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val b = icon
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)))
        } else {
            Icon(Icons.Rounded.Android, null, tint = C.Ok, modifier = Modifier.size(42.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(app.label, color = Color.White, maxLines = 1, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(fmtSize(app.size) + if (app.files.size > 1) "  ·  Split APK" else "", color = C.Lo, fontSize = 12.sp)
        }
        CheckDot(selected)
    }
}

@Composable
fun AppsTab(picked: SnapshotStateList<PickedFile>) {
    val ctx = LocalContext.current
    val apps by produceState<List<AppItem>?>(null) {
        value = withContext(Dispatchers.IO) { MediaRepo.queryApps(ctx) }
    }
    var q by remember { mutableStateOf("") }
    val list = apps
    if (list == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            androidx.compose.material3.CircularProgressIndicator(color = C.Blue)
        }
        return
    }
    val shown = if (q.isBlank()) list else list.filter { it.label.contains(q, ignoreCase = true) }
    val selectedUris = picked.map { it.uri }.toHashSet()
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = C.Lo) },
            placeholder = { Text(stringResource(R.string.search_apps), color = C.Lo) },
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.pkg }) { app ->
                val sel = app.files.first().uri in selectedUris
                AppRow(app, sel) {
                    if (sel) {
                        val u = app.files.map { it.uri }.toHashSet()
                        picked.removeAll { it.uri in u }
                    } else {
                        val have = picked.map { it.uri }.toHashSet()
                        picked.addAll(app.files.filter { it.uri !in have })
                    }
                }
            }
        }
    }
}

@Composable
fun PickScreen(
    tab: Int, onTab: (Int) -> Unit, picked: SnapshotStateList<PickedFile>,
    onBack: () -> Unit, onSend: () -> Unit
) {
    var review by remember { mutableStateOf(false) }
    val tabs = listOf(
        Pair(Icons.Rounded.Image, R.string.tab_photos),
        Pair(Icons.Rounded.Folder, R.string.tab_files),
        Pair(Icons.Rounded.Videocam, R.string.tab_videos),
        Pair(Icons.Rounded.Android, R.string.tab_apps)
    )
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopBar(stringResource(R.string.pick_title), onBack)
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tabs.forEachIndexed { i, t ->
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(if (i == tab) C.Blue else C.Card)
                            .clickable { onTab(i) }.padding(vertical = 9.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(t.first, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        Text(stringResource(t.second), color = Color.White, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> MediaGrid(false, picked)
                    2 -> MediaGrid(true, picked)
                    1 -> FilesTab(picked)
                    else -> AppsTab(picked)
                }
            }
            Row(
                Modifier.fillMaxWidth().background(C.Card).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f).clickable(enabled = picked.isNotEmpty()) { review = true }) {
                    Text(stringResource(R.string.selected_count, picked.size), color = Color.White, fontWeight = FontWeight.Bold)
                    Text(fmtSize(picked.sumOf { it.size }), color = C.Lo, fontSize = 12.sp)
                }
                GradientButton(
                    stringResource(R.string.send_now), onSend, Modifier.width(170.dp),
                    icon = Icons.Rounded.Send, enabled = picked.isNotEmpty()
                )
            }
        }
        if (review) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.7f)).clickable { review = false }.padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(Modifier.fillMaxWidth().card(24.dp).clickable(enabled = false) {}.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.selected_count, picked.size), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { picked.clear(); review = false }) { Text(stringResource(R.string.clear_all), color = C.Err) }
                    }
                    LazyColumn(Modifier.height(360.dp)) {
                        items(picked.toList(), key = { it.uri.toString() }) { f ->
                            SelectedRow(f) {
                                picked.remove(f)
                                if (picked.isEmpty()) review = false
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    SoftButton(stringResource(R.string.close), { review = false }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}
