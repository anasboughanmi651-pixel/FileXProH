package com.filex.pro

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

@Composable
fun KeepScreenOn() {
    val v = LocalView.current
    DisposableEffect(Unit) {
        v.keepScreenOn = true
        onDispose { v.keepScreenOn = false }
    }
}

@Composable
fun AskNotifOnce() {
    val ctx = LocalContext.current
    val l = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Prefs.notifAsked(ctx) &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            Prefs.setNotifAsked(ctx)
            l.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@Composable
fun errText(e: ErrInfo?): String = if (e == null) "" else stringResource(e.res, e.arg ?: "")

@Composable
fun StatTile(icon: ImageVector, value: String, label: String, modifier: Modifier) {
    Column(modifier.card(16.dp).padding(vertical = 12.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = C.Cyan, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(4.dp))
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
        Text(label, color = C.Lo, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun FileLine(name: String, size: Long, status: Int, progress: Float) {
    // status: 0 waiting, 1 done, 2 failed, 3 active
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).card(14.dp).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(iconForName(name), null, tint = if (status == 3) C.Blue else C.Lo, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Color.White, fontSize = 14.sp, maxLines = 1)
                Text(fmtSize(size), color = C.Lo, fontSize = 11.sp)
            }
            when (status) {
                1 -> Icon(Icons.Rounded.CheckCircle, null, tint = C.Ok, modifier = Modifier.size(22.dp))
                2 -> Icon(Icons.Rounded.Warning, null, tint = C.Warn, modifier = Modifier.size(22.dp))
                3 -> Text("${(progress * 100).toInt()}%", color = C.Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                else -> Icon(Icons.Rounded.Schedule, null, tint = C.Lo.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
            }
        }
        if (status == 3) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = C.Blue, trackColor = Color.White.copy(alpha = 0.08f)
            )
        }
    }
}

@Composable
fun FileList(st: TransferState, modifier: Modifier) {
    val prefix = remember(st.sizes) {
        var s = 0L
        st.sizes.map { v ->
            val r = s
            s += v
            r
        }
    }
    LazyColumn(modifier) {
        itemsIndexed(st.names) { i, name ->
            val size = st.sizes.getOrElse(i) { 0L }
            val status = when {
                i in st.failed -> 2
                st.phase == Phase.Done || i < st.currentIndex -> 1
                i == st.currentIndex && st.phase == Phase.Transferring -> 3
                else -> 0
            }
            val p = if (size > 0 && status == 3) ((st.doneBytes - prefix.getOrElse(i) { 0L }).toFloat() / size).coerceIn(0f, 1f) else 0f
            FileLine(name, size, status, p)
        }
    }
}

@Composable
fun TransferBody(st: TransferState, sending: Boolean, onStop: () -> Unit, onFinish: () -> Unit, onRetry: () -> Unit) {
    val ctx = LocalContext.current
    when (st.phase) {
        Phase.Transferring -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                Modifier.card(30.dp).padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(C.Ok))
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Rounded.Wifi, null, tint = C.Cyan, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    stringResource(if (sending) R.string.sending_to else R.string.receiving_from, st.peerName.ifBlank { "…" }),
                    color = Color.White, fontSize = 13.sp, maxLines = 1
                )
            }
            Spacer(Modifier.height(18.dp))
            ProgressRing(st.percent, Modifier.size(200.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${(st.percent * 100).toInt()}%", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "${minOf(st.currentIndex + 1, st.fileCount)} / ${st.fileCount}",
                        color = C.Lo, fontSize = 13.sp
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile(Icons.Rounded.Speed, fmtSpeed(st.speedBps), stringResource(R.string.speed), Modifier.weight(1f))
                StatTile(Icons.Rounded.Schedule, fmtTime(st.remainingSec), stringResource(R.string.remaining), Modifier.weight(1f))
                StatTile(Icons.Rounded.Storage, fmtSize(st.doneBytes), "/ " + fmtSize(st.totalBytes), Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            FileList(st, Modifier.weight(1f))
            Spacer(Modifier.height(8.dp))
            SoftButton(stringResource(R.string.stop), onStop, Modifier.fillMaxWidth(), color = C.Err)
            Spacer(Modifier.height(12.dp))
        }

        Phase.Done -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val sc = remember { Animatable(0.4f) }
            LaunchedEffect(Unit) { sc.animateTo(1f, spring(dampingRatio = 0.45f)) }
            Spacer(Modifier.height(12.dp))
            Icon(Icons.Rounded.CheckCircle, null, tint = C.Ok, modifier = Modifier.size(96.dp).scale(sc.value))
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.done_title), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
                stringResource(R.string.files_count_size, st.fileCount - st.failed.size, fmtSize(st.totalBytes)),
                color = C.Lo, fontSize = 14.sp
            )
            Spacer(Modifier.height(12.dp))
            val dur = st.durationSec
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile(Icons.Rounded.Schedule, fmtTime(dur), stringResource(R.string.duration), Modifier.weight(1f))
                StatTile(
                    Icons.Rounded.Speed,
                    if (dur > 0) fmtSpeed(st.totalBytes.toDouble() / dur) else "--",
                    stringResource(R.string.avg_speed), Modifier.weight(1f)
                )
            }
            if (st.verified > 0 || st.mismatched > 0) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().card(14.dp).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (st.mismatched == 0) Icons.Rounded.VerifiedUser else Icons.Rounded.Warning, null,
                        tint = if (st.mismatched == 0) C.Ok else C.Warn, modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (st.mismatched == 0) stringResource(R.string.verified_fmt, st.verified)
                        else stringResource(R.string.mismatch_fmt, st.mismatched),
                        color = Color.White, fontSize = 13.sp
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            FileList(st, Modifier.weight(1f))
            Spacer(Modifier.height(8.dp))
            if (!sending) {
                SoftButton(stringResource(R.string.open_folder), {
                    try {
                        ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
            }
            GradientButton(stringResource(R.string.finish), onFinish, Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
        }

        Phase.Failed -> Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Rounded.Error, null, tint = C.Err, modifier = Modifier.size(84.dp))
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.failed_title), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(errText(st.error), color = C.Lo, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            GradientButton(stringResource(R.string.retry), onRetry, Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            SoftButton(stringResource(R.string.back), onFinish, Modifier.fillMaxWidth())
        }

        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = C.Blue) }
    }
}

@Composable
fun StopDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.Card,
        title = { Text(stringResource(R.string.stop_title), color = Color.White) },
        text = { Text(stringResource(R.string.stop_msg), color = C.Lo) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(stringResource(R.string.stop), color = C.Err) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.continue_transfer)) } }
    )
}

// ---------- شاشة الإرسال ----------
@Composable
fun SendScreen(onClose: () -> Unit, onBackToPick: () -> Unit, onRetry: () -> Unit) {
    val st by Engine.sendState.collectAsState()
    val qr by Engine.qr.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    KeepScreenOn()
    AskNotifOnce()
    DisposableEffect(Unit) { onDispose { Engine.stopSending() } }
    LaunchedEffect(st.phase) { if (st.phase == Phase.Idle) onClose() }
    BackHandler { if (st.phase == Phase.Transferring) confirm = true else onBackToPick() }

    Column(Modifier.fillMaxSize()) {
        if (st.phase == Phase.Preparing || st.phase == Phase.Waiting || st.phase == Phase.Idle) {
            TopBar(stringResource(R.string.send_title), onBackToPick)
            val bmp = remember(qr) { qr?.let { qrBitmap(it) } }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.card(30.dp).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Storage, null, tint = C.Cyan, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.files_count_size, st.fileCount, fmtSize(st.totalBytes)), color = Color.White, fontSize = 13.sp)
                }
                Spacer(Modifier.height(16.dp))
                Box(Modifier.size(310.dp), contentAlignment = Alignment.Center) {
                    PulseRings(Modifier.fillMaxSize())
                    Box(Modifier.size(236.dp).clip(RoundedCornerShape(26.dp)).background(Color.White), contentAlignment = Alignment.Center) {
                        if (bmp != null) {
                            Image(bmp.asImageBitmap(), null, Modifier.size(212.dp))
                        } else {
                            CircularProgressIndicator(color = C.Blue)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.waiting_title), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(stringResource(R.string.waiting_sub), color = C.Lo, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                Column(Modifier.fillMaxWidth().card(18.dp).padding(14.dp)) {
                    Text("1  " + stringResource(R.string.step_open_receive), color = Color.White, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("2  " + stringResource(R.string.step_scan), color = Color.White, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("3  " + stringResource(R.string.step_same_network), color = C.Lo, fontSize = 13.sp)
                }
                Spacer(Modifier.height(16.dp))
                SoftButton(stringResource(R.string.cancel), onBackToPick, Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
            }
        } else {
            TopBar(stringResource(R.string.send_title), null)
            Box(Modifier.weight(1f)) {
                TransferBody(st, true, { confirm = true }, onClose, onRetry)
            }
        }
    }
    if (confirm) {
        StopDialog(onConfirm = { confirm = false; Engine.stopSending() }, onDismiss = { confirm = false })
    }
}

// ---------- شاشة الاستقبال ----------
@Composable
fun ReceiveScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val st by Engine.recvState.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    KeepScreenOn()
    AskNotifOnce()
    DisposableEffect(Unit) {
        Engine.clearReceiveIfIdle()
        onDispose { Engine.cancelReceive() }
    }
    val scanPrompt = stringResource(R.string.scan_prompt)
    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { res ->
        val t = res.contents
        if (t != null) Engine.receive(ctx, t)
    }
    val doScan = {
        val o = ScanOptions()
        o.setDesiredBarcodeFormats(ScanOptions.QR_CODE)
        o.setPrompt(scanPrompt)
        o.setBeepEnabled(false)
        o.setOrientationLocked(false)
        scanLauncher.launch(o)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) doScan() }
    val startScan = {
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            doScan()
        }
    }
    BackHandler { if (st.phase == Phase.Transferring) confirm = true else onClose() }

    Column(Modifier.fillMaxSize()) {
        when (st.phase) {
            Phase.Idle -> {
                TopBar(stringResource(R.string.receive_title), onClose)
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
                        PulseRings(Modifier.fillMaxSize(), C.Violet)
                        Box(Modifier.size(120.dp).clip(CircleShape).background(C.recvBrush), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.QrCodeScanner, null, tint = Color.White, modifier = Modifier.size(60.dp))
                        }
                    }
                    Text(stringResource(R.string.receive_idle_title), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(stringResource(R.string.receive_idle_sub), color = C.Lo, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(20.dp))
                    GradientButton(stringResource(R.string.scan_qr), startScan, Modifier.fillMaxWidth(), Icons.Rounded.QrCodeScanner, C.recvBrush)
                    Spacer(Modifier.height(16.dp))
                }
            }
            Phase.Transferring, Phase.Done, Phase.Failed -> {
                TopBar(stringResource(R.string.receive_title), null)
                Box(Modifier.weight(1f)) {
                    TransferBody(
                        st, false, { confirm = true },
                        { Engine.cancelReceive(); onClose() },
                        { Engine.cancelReceive() }
                    )
                }
            }
            else -> {
                TopBar(stringResource(R.string.receive_title), null)
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = C.Violet)
                    Spacer(Modifier.height(14.dp))
                    Text(stringResource(R.string.connecting), color = C.Lo)
                }
            }
        }
    }
    if (confirm) {
        StopDialog(onConfirm = { confirm = false; Engine.cancelReceive() }, onDismiss = { confirm = false })
    }
}
