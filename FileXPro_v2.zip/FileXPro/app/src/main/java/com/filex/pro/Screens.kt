package com.filex.pro

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ---------- الرئيسية ----------
@Composable
fun ActionCard(title: String, sub: String, icon: ImageVector, brush: Brush, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(112.dp).clip(RoundedCornerShape(26.dp)).background(brush)
            .clickable(onClick = onClick).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(icon, size = 58.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }
}

@Composable
fun ToolCard(label: String, icon: ImageVector, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(92.dp).card(18.dp).clickable(onClick = onClick).padding(12.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconBubble(icon, tint = tint, bg = tint.copy(alpha = 0.16f), size = 40.dp)
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
fun FeatureRow(icon: ImageVector, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = C.Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, color = C.Lo, fontSize = 13.sp)
    }
}

@Composable
fun HomeScreen(
    onSend: () -> Unit, onReceive: () -> Unit, onTool: (Int) -> Unit, onShareApp: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            CrownIcon(30.dp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("FileX Pro", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text(stringResource(R.string.tagline), color = C.Lo, fontSize = 13.sp)
            }
        }
        ActionCard(stringResource(R.string.send_files), stringResource(R.string.send_sub), Icons.Rounded.Upload, C.sendBrush, onSend)
        Spacer(Modifier.height(14.dp))
        ActionCard(stringResource(R.string.receive_files), stringResource(R.string.receive_sub), Icons.Rounded.Download, C.recvBrush, onReceive)
        Spacer(Modifier.height(22.dp))
        Text(stringResource(R.string.tools), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ToolCard(stringResource(R.string.tool_apps), Icons.Rounded.Apps, C.Cyan, Modifier.weight(1f)) { onTool(3) }
            ToolCard(stringResource(R.string.tool_gallery), Icons.Rounded.Image, C.Blue, Modifier.weight(1f)) { onTool(0) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ToolCard(stringResource(R.string.tool_big_files), Icons.Rounded.Folder, C.Violet, Modifier.weight(1f)) { onTool(1) }
            ToolCard(stringResource(R.string.tool_share_app), Icons.Rounded.Share, C.Ok, Modifier.weight(1f), onShareApp)
        }
        Spacer(Modifier.height(22.dp))
        Column(Modifier.fillMaxWidth().card(20.dp).padding(16.dp)) {
            FeatureRow(Icons.Rounded.WifiOff, stringResource(R.string.feat_offline))
            FeatureRow(Icons.Rounded.Speed, stringResource(R.string.feat_fast))
            FeatureRow(Icons.Rounded.Lock, stringResource(R.string.feat_encrypted))
            FeatureRow(Icons.Rounded.VerifiedUser, stringResource(R.string.feat_verified))
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ---------- السجل ----------
@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    var records by remember { mutableStateOf(Engine.history(ctx)) }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.history), null) {
            if (records.isNotEmpty()) {
                IconButton(onClick = { confirm = true }) { Icon(Icons.Rounded.Delete, null, tint = C.Lo) }
            }
        }
        if (records.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                IconBubble(Icons.Rounded.History, tint = C.Lo, bg = Color.White.copy(alpha = 0.06f), size = 80.dp)
                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.history_empty), color = C.Lo, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                items(records) { h -> HistoryRow(h) }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = C.Card,
            title = { Text(stringResource(R.string.history_clear_title), color = Color.White) },
            text = { Text(stringResource(R.string.history_clear_msg), color = C.Lo) },
            confirmButton = {
                TextButton(onClick = {
                    Engine.clearHistory(ctx)
                    records = emptyList()
                    confirm = false
                }) { Text(stringResource(R.string.yes_clear), color = C.Err) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
fun HistoryRow(h: HistoryItem) {
    val sent = h.dir == "sent"
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).card(18.dp).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(
            if (sent) Icons.Rounded.Upload else Icons.Rounded.Download,
            tint = if (sent) C.Blue else C.Violet,
            bg = (if (sent) C.Blue else C.Violet).copy(alpha = 0.16f)
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(if (sent) R.string.history_sent else R.string.history_received) +
                    (if (h.peer.isNotBlank()) "  ·  " + h.peer else ""),
                color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1
            )
            Text(
                stringResource(R.string.files_count_size, h.count, fmtSize(h.bytes)) +
                    (if (h.durationSec > 0) "  ·  " + fmtTime(h.durationSec) else ""),
                color = C.Lo, fontSize = 12.sp
            )
            Text(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(h.time)), color = C.Lo.copy(alpha = 0.7f), fontSize = 11.sp)
        }
        Icon(
            if (h.ok) Icons.Rounded.CheckCircle else Icons.Rounded.Warning, null,
            tint = if (h.ok) C.Ok else C.Warn, modifier = Modifier.size(24.dp)
        )
    }
}

// ---------- الإعدادات ----------
@Composable
fun SettingRow(icon: ImageVector, title: String, sub: String?, onClick: (() -> Unit)?) {
    val m = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).card(16.dp).then(m).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(icon, tint = C.Cyan, bg = C.Cyan.copy(alpha = 0.14f), size = 40.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            if (sub != null) Text(sub, color = C.Lo, fontSize = 12.sp)
        }
    }
}

@Composable
fun SettingsScreen(onPrivacy: () -> Unit, onShareApp: () -> Unit, onLanguageChanged: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(Prefs.deviceName(ctx)) }
    var showName by remember { mutableStateOf(false) }
    var showLang by remember { mutableStateOf(false) }
    val lang = Prefs.lang(ctx)
    val langLabel = when (lang) {
        "ar" -> "العربية"
        "en" -> "English"
        "fr" -> "Français"
        else -> stringResource(R.string.lang_system)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        TopBar(stringResource(R.string.settings), null)
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.foundation.Image(
                androidx.compose.ui.res.painterResource(R.drawable.filex_icon), null,
                Modifier.size(84.dp).clip(RoundedCornerShape(22.dp))
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CrownIcon(22.dp)
                Spacer(Modifier.width(6.dp))
                Text("FileX Pro", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Text(stringResource(R.string.version_fmt, "2.0"), color = C.Lo, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        SettingRow(Icons.Rounded.PhoneAndroid, stringResource(R.string.device_name), name) { showName = true }
        SettingRow(Icons.Rounded.Language, stringResource(R.string.language), langLabel) { showLang = true }
        SettingRow(Icons.Rounded.Storage, stringResource(R.string.save_location), stringResource(R.string.save_location_sub), null)
        SettingRow(Icons.Rounded.Share, stringResource(R.string.tool_share_app), stringResource(R.string.share_app_sub), onShareApp)
        SettingRow(Icons.Rounded.Security, stringResource(R.string.privacy), stringResource(R.string.privacy_sub), onPrivacy)
        SettingRow(Icons.Rounded.Info, stringResource(R.string.about), stringResource(R.string.about_sub), null)
        Signature()
    }
    if (showName) {
        var tmp by remember { mutableStateOf(name) }
        AlertDialog(
            onDismissRequest = { showName = false },
            containerColor = C.Card,
            title = { Text(stringResource(R.string.device_name), color = Color.White) },
            text = {
                OutlinedTextField(value = tmp, onValueChange = { tmp = it.take(32) }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    if (tmp.isNotBlank()) {
                        Prefs.setDeviceName(ctx, tmp)
                        name = Prefs.deviceName(ctx)
                    }
                    showName = false
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { showName = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (showLang) {
        val opts = listOf("" to stringResource(R.string.lang_system), "ar" to "العربية", "en" to "English", "fr" to "Français")
        AlertDialog(
            onDismissRequest = { showLang = false },
            containerColor = C.Card,
            title = { Text(stringResource(R.string.language), color = Color.White) },
            text = {
                Column {
                    opts.forEach { (code, label) ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                showLang = false
                                if (code != lang) {
                                    Prefs.setLang(ctx, code)
                                    onLanguageChanged()
                                }
                            }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = code == lang, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Text(label, color = Color.White)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.privacy), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Text(stringResource(R.string.privacy_body), color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, lineHeight = 22.sp)
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ---------- شريط التنقل ----------
@Composable
fun FxNavBar(nav: Int, onNav: (Int) -> Unit) {
    NavigationBar(containerColor = C.Card, windowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0)) {
        val items = listOf(
            Pair(Icons.Rounded.Home, R.string.nav_home),
            Pair(Icons.Rounded.History, R.string.nav_history),
            Pair(Icons.Rounded.Settings, R.string.nav_settings)
        )
        items.forEachIndexed { i, it ->
            NavigationBarItem(
                selected = nav == i, onClick = { onNav(i) },
                icon = { Icon(it.first, null) },
                label = { Text(stringResource(it.second), fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White, selectedTextColor = C.Blue,
                    indicatorColor = C.Blue, unselectedIconColor = C.Lo, unselectedTextColor = C.Lo
                )
            )
        }
    }
}
